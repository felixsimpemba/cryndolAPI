<?php

namespace App\Http\Controllers;

class ApiDocController extends Controller
{
    // Deprecated: Top-level OpenAPI annotations have been consolidated into App\OpenApi\Docs.
    // This class intentionally contains no OpenAPI annotations to avoid duplicates in Swagger UI.
}
