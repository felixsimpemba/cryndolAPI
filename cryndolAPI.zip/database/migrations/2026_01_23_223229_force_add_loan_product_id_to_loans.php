<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (!Schema::hasColumn('loans', 'loan_product_id')) {
            Schema::table('loans', function (Blueprint $table) {
                $table->foreignId('loan_product_id')->nullable()->after('status')->constrained('loan_products')->nullOnDelete();
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasColumn('loans', 'loan_product_id')) {
            Schema::table('loans', function (Blueprint $table) {
                $table->dropForeign(['loan_product_id']);
                $table->dropColumn('loan_product_id');
            });
        }
    }
};
